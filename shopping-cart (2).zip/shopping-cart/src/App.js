
import {BrowserRouter as Router,Route,Routes } from 'react-router-dom';
import './App.css';
import Navbar from './containers/cart/products/navbar/Navbar';
import ProductScreen from './containers/cart/products/ProductScreen';
import CartScreen from './containers/cart/CartScreen'
import { Switch } from 'react-router-dom/cjs/react-router-dom.min';

function App() {
  return (
    <Router>

<div className="App">
  <Navbar/>
  <Switch>
  <Route exact path='/products'>
  <ProductScreen />
  </Route>
   
  <Route exact path='/cart'>
  <CartScreen />
  </Route> 
  </Switch>
    </div>

    </Router>
    
  );
}

export default App;
