import React from 'react'
import {products} from '../../../constants/product' ;
import ProductItem from '../../../product/ProductItem';
import { PageHeading,
    ProductContainerStyle ,
}
 from '../../../styles/ProductScreen';
import { useDispatch,useSelector } from 'react-redux';
import { listProducts } from '../../../actions/productActions';


const ProductScreen = () => {
const dispatch = useDispatch()

const productList=useSelector((state)=>state.productList);

const{loading ,error ,products}=productList;

React.useEffect(()=>{
    dispatch(listProducts())
},[dispatch])

  return (
    <div>
        {loading ?(
            <div> Loading...</div>
           ) :error?(
                <div>{error}</div>
            ):(

                <>

<PageHeading primary>Products</PageHeading>
        <ProductContainerStyle>
        {products.map((item, xid)=>(
            <div key={xid}>
            <ProductItem  item={item}/>

            </div>
        ))}
            </ProductContainerStyle>

                </>
            )}
        
        
    </div>
  )
}

export default ProductScreen