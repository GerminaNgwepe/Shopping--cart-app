// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from 'firebase/firestore';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA2gmiRut-TJs7LSFv-wYHbbmdP-u3AhEY",
  authDomain: "shopping-cart-app-fa1a2.firebaseapp.com",
  projectId: "shopping-cart-app-fa1a2",
  storageBucket: "shopping-cart-app-fa1a2.appspot.com",
  messagingSenderId: "1096275970665",
  appId: "1:1096275970665:web:e5f8c59ecc1206233030f8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db= getFirestore(app);


export default db