import React from 'react'
import { CartAddButton, ProductItemStyle } from '../styles/ProductScreen';
import { useDispatch } from 'react-redux';
import { addProductToCart } from '../actions/CartActions';


const ProductItem=({item}) =>{

const dispatch=useDispatch();
const addToCartHandler=()=>{
    
    dispatch(addProductToCart(item))
}


  return (
    <div style={{backgroundColor:'white',
    padding:'12px',
    margin:'10px'}}>
        <img  style={{width:'150px' ,height:'150px'}} src={item.image} alt={item.title}/> 
        <h3
        style={{border: '1px solid black',
                borderRadius: '2px',
                padding: '1rem',
    
    }}
        >
            {item.title}</h3>
        <p style={{
            fontSize:'20px',
            color:'black',
        }}
        >R{item.price}</p>
        <p>{item.quantity}</p>
        <p
        style={{
            fontSize:'13px',
            color:'black',
        }}>
            {item.description}</p>
            <CartAddButton onClick={addToCartHandler} primary>Add To Cart</CartAddButton>
            <ProductItemStyle/>
    </div>
  )
}

export default ProductItem