//import { createStore,combineReducers,applyMiddleware} from "react-redux";
import thunk from "redux-thunk";
import { createStore,combineReducers,applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import { productlistReducer } from "./reducers/ProductReducers";
import { listCartItemsReducer } from "./reducers/CartReducer";
import { addItemToCartReducer } from "./reducers/CartReducer";



const reducer=combineReducers({
    productList:productlistReducer,
    cartItemsList: listCartItemsReducer,
    addToCart: addItemToCartReducer,
});

const initialState={};

const middleware=[thunk];

const store =createStore(
    reducer,
    initialState,
    composeWithDevTools(applyMiddleware(...middleware))
)

export default  store;